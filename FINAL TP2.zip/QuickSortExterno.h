#define TAMAREA 20
#include "structs.h"
#include <stdio.h>
#include <limits.h>
#include <float.h>
#include <stdbool.h>

typedef int Apontador;

typedef struct Celula{
    Registro Item;
    Apontador Prox, Ant;
} Celula;

typedef struct TArea{
    Celula Itens[TAMAREA];
    Apontador CelulasDisp, Primeiro, Ultimo;
    int NumCelOcupadas;
} TArea;

// Quicksort Externo

void FAVazia(TArea* Area){
    int i;
    Area->NumCelOcupadas = 0;
    Area->Primeiro = -1;
    Area->Ultimo = -1;
    Area->CelulasDisp = 0;
    for (i = 0; i < TAMAREA; i++){
        Area->Itens[i].Ant = -1;
        Area->Itens[i].Prox = i + 1;
    }
}

int ObterNumCelOcupadas(TArea* Area){
    return (Area->NumCelOcupadas);
}

void InsereItem(Registro Item, TArea* Area, int* comp){
    int pos, disp, IndiceInsercao;
    if (Area->NumCelOcupadas == TAMAREA){
        printf("Tentativa de inserção em memoria cheia.\n");
        return;
    }
    disp = Area->CelulasDisp;
    Area->CelulasDisp = Area->Itens[Area->CelulasDisp].Prox;
    Area->Itens[disp].Item = Item;
    Area->NumCelOcupadas++;
    if (Area->NumCelOcupadas == 1){
        /*Inserção do primeiro item*/
        Area->Primeiro = disp;
        Area->Ultimo = Area->Primeiro;
        Area->Itens[Area->Primeiro].Prox = -1;
        Area->Itens[Area->Primeiro].Ant = -1;
        return;
    }
    pos = Area->Primeiro;
    (*comp)++;
    if (Item.nota < Area->Itens[pos].Item.nota){
        /*Inserção na primeira posição*/
        Area->Itens[disp].Ant = -1;
        Area->Itens[disp].Prox = pos;
        Area->Itens[pos].Ant = disp;
        Area->Primeiro = disp;
        return;
    }
    IndiceInsercao = Area->Itens[pos].Prox;
    while (IndiceInsercao != -1 && Area->Itens[IndiceInsercao].Item.nota < Item.nota){
        (*comp)++;
        pos = IndiceInsercao;
        IndiceInsercao = Area->Itens[pos].Prox;
    }
    (*comp)++;
    if (IndiceInsercao == -1){
        /*Inserção realizada na ultima posição*/
        Area->Itens[disp].Ant = pos;
        Area->Itens[disp].Prox = -1;
        Area->Itens[pos].Prox = disp;
        Area->Ultimo = disp;
        return;
    }
    Area->Itens[disp].Ant = pos;
    Area->Itens[disp].Prox = Area->Itens[pos].Prox;
    Area->Itens[pos].Prox = disp;
    pos = Area->Itens[disp].Prox;
    Area->Itens[pos].Ant = disp;
    /*Inserção realizada no meio da área*/
}

void RetiraPrimeiro(TArea* Area, Registro* Item){
    Apontador ProxTmp;
    if (Area->NumCelOcupadas == 0){
        printf("Erro. Memoria vazia\n");
        return;
    }
    *Item = Area->Itens[Area->Primeiro].Item;
    ProxTmp = Area->Itens[Area->Primeiro].Prox;
    Area->Itens[Area->Primeiro].Prox = Area->CelulasDisp;
    Area->CelulasDisp = Area->Primeiro;
    Area->Primeiro = ProxTmp;
    if ((unsigned int)Area->Primeiro < TAMAREA)
        Area->Itens[Area->Primeiro].Ant = -1;
    Area->NumCelOcupadas--;
}

void RetiraUltimo(TArea* Area, Registro* Item){
    Apontador AntTmp;
    if (Area->NumCelOcupadas == 0){
        printf("Erro. Memoria vazia\n");
        return;
    }
    *Item = Area->Itens[Area->Ultimo].Item;
    AntTmp = Area->Itens[Area->Ultimo].Ant;
    Area->Itens[Area->Ultimo].Prox = Area->CelulasDisp;
    Area->CelulasDisp = Area->Ultimo;
    Area->Ultimo = AntTmp;
    if ((unsigned int)Area->Ultimo < TAMAREA)
        Area->Itens[Area->Ultimo].Prox = -1;
    Area->NumCelOcupadas--;

}

void ImprimeArea(TArea* Area){
    int pos;
    if (Area->NumCelOcupadas <= 0){
        printf("Memoria vazia\n");
        return;
    }
    printf("Memoria\n");
    printf("Numero de celulas ocupadas: %d\n", Area->NumCelOcupadas);
    pos = Area->Primeiro;
    while (pos != -1){
        printf("%f ", Area->Itens[pos].Item.nota);
        pos = Area->Itens[pos].Prox;
    }
}

/*Procedimentos utilizados pela Partição do QuickSort*/

void LeSup(FILE** ArqLEs, Registro* UltLido, int* Ls, short* OndeLer, int* leit){
    fseek(*ArqLEs, (*Ls - 1) * sizeof(Registro), SEEK_SET);
    fread(UltLido, sizeof(Registro), 1, *ArqLEs);
    (*leit)++;
    (*Ls)--;
    *OndeLer = false;
}

void LeInf(FILE** ArqLi, Registro* UltLido, int* Li, short* OndeLer, int* leit){
    fread(UltLido, sizeof(Registro), 1, *ArqLi);
    (*leit)++;
    (*Li)++;
    *OndeLer = true;
}

void InserirArea(TArea* Area, Registro* UltLido, int* NRArea, int* comp){
    /*Insere UltLido de forma ordenada na área*/
    InsereItem(*UltLido, Area, comp);
    *NRArea = ObterNumCelOcupadas(Area);
}

void EscreveMax(FILE** ArqLEs, Registro R, int* Es, int* transf){
    fseek(*ArqLEs, (*Es - 1) * sizeof(Registro), SEEK_SET);
    fwrite(&R, sizeof(Registro), 1, *ArqLEs);
    (*transf)++;
    (*Es)--;
}

void EscreveMin(FILE** ArqEi, Registro R, int* Ei, int* transf){
    fwrite(&R, sizeof(Registro), 1, *ArqEi);
    (*transf)++;
    (*Ei)++;
}

void RetiraMax(TArea* Area, Registro* R, int* NRArea, int* comp){
    RetiraUltimo(Area, R);
    *NRArea = ObterNumCelOcupadas(Area);
}

void RetiraMin(TArea* Area, Registro* R, int* NRArea, int* comp){
    RetiraPrimeiro(Area, R);
    *NRArea = ObterNumCelOcupadas(Area);
}

void Particao(FILE** ArqLi, FILE** ArqEi, FILE** ArqLEs, TArea Area, int Esq, int Dir, int* i, int* j, int* leit, int* transf, int* comp){
    int Ls = Dir, Es = Dir, Li = Esq, Ei = Esq, NRArea = 0;
    double Linf = DBL_MIN, Lsup = DBL_MAX;
    short OndeLer = true;
    Registro UltLido, R;
    fseek(*ArqLi, (Li - 1) * sizeof(Registro), SEEK_SET);
    fseek(*ArqEi, (Ei - 1) * sizeof(Registro), SEEK_SET);
    *i = Esq - 1;
    *j = Dir + 1;
    while (Ls >= Li){
        if (NRArea < TAMAREA - 1){
            if (OndeLer) LeSup(ArqLEs, &UltLido, &Ls, &OndeLer, leit);
            else LeInf(ArqLi, &UltLido, &Li, &OndeLer, leit);
            InserirArea(&Area, &UltLido, &NRArea, comp);
            continue;
        }
        if (Ls == Es) LeSup(ArqLEs, &UltLido, &Ls, &OndeLer, leit);
        else if (Li == Ei) LeInf(ArqLi, &UltLido, &Li, &OndeLer, leit);
        else if (OndeLer) LeSup(ArqLEs, &UltLido, &Ls, &OndeLer, leit);
        else LeInf(ArqLi, &UltLido, &Li, &OndeLer, leit);
        (*comp)++;
        if (UltLido.nota > Lsup){
            *j = Es;
            EscreveMax(ArqLEs, UltLido, &Es, transf);
            continue;
        }
        (*comp)++;
        if (UltLido.nota < Linf){
            *i = Ei;
            EscreveMin(ArqEi, UltLido, &Ei, transf);
            continue;
        }
        InserirArea(&Area, &UltLido, &NRArea, comp);
        if (Ei - Esq < Dir - Es){
            RetiraMin(&Area, &R, &NRArea, comp);
            EscreveMin(ArqEi, R, &Ei, transf);
            Linf = R.nota;
        } else {
            RetiraMax(&Area, &R, &NRArea, comp);
            EscreveMax(ArqLEs, R, &Es, comp);
            Lsup = R.nota;
        }
    }
    while (Ei <= Es){
        RetiraMin(&Area, &R, &NRArea, comp);
        EscreveMin(ArqEi, R, &Ei, comp);
    }
}

void QuickSortExterno(FILE** ArqLi, FILE** ArqEi, FILE** ArqLEs, int Esq, int Dir, int* leit, int* transf, int* comp){
    int i, j;
    TArea Area; /*Área de armazenamento interna*/
    if (Dir - Esq < 1) return;
    FAVazia(&Area);
    Particao(ArqLi, ArqEi, ArqLEs, Area, Esq, Dir, &i, &j, leit, transf, comp);
    if (i - Esq < Dir - j){
        /*Ordena primeiro o subarquivo menor */
        QuickSortExterno(ArqLi, ArqEi, ArqLEs, Esq, i, leit, transf, comp);
        QuickSortExterno(ArqLi, ArqEi, ArqLEs, j, Dir, leit, transf, comp);
    } else {
        QuickSortExterno(ArqLi, ArqEi, ArqLEs, j, Dir, leit, transf, comp);
        QuickSortExterno(ArqLi, ArqEi, ArqLEs, Esq, i, leit, transf, comp);
    }
}