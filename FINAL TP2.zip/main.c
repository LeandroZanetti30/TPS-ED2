#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "structs.h"
#include "listaEncadeada.h"
#include "Intercalacoes.h"
#include "QuickSortExterno.h"

// Função responsável por criar o arquivo temporario que irá ser utilizado para ser ordenado
void criarArquivoTemporario(FILE* arqProvao, FILE* arqTemporario, int quantidade, int* escritas){
    Registro registro;
    for (int i = 0; i < quantidade; i++){
        // Fazendo a leitura do numero de inscrição, nota e um ' ' no final para começar a ler o proximo dado
        fscanf(arqProvao, "%ld %lf ", &registro.numeroInscricao, &registro.nota);
        // Lê o estado e da o fseek para pular o espaço
        fgets(registro.estado, 3, arqProvao);
        fseek(arqProvao, 1, SEEK_CUR);
        // Lê a cidade e da o fseek para pular o espaço
        fgets(registro.cidade, 51, arqProvao);
        fseek(arqProvao, 1, SEEK_CUR);
        // Lê o curso
        fgets(registro.curso, 31, arqProvao);
        fseek(arqProvao, 1, SEEK_CUR);
        fwrite(&registro, sizeof(Registro), 1, arqTemporario);
        (*escritas)++;
    }
    rewind(arqTemporario);
}

int main(int argc, char* argv []){
    int metodo, quantidade, situacao, imprimirDados;
    // 1 = IBVC, 2 = IBVC Seleção por Substituição, 3 = Quicksort externo
    metodo = atoi(argv[1]);
    // Quantidade de registros do arquivo
    quantidade = atoi(argv[2]);
    // Situação de ordem do arquivo, 1 = Ascendente, 2 = Decrescente, 3 = Aleatório
    situacao = atoi(argv[3]);
    // Argumento [-P] = Apresentar no console os dados dos alunos a serem ordenados e o resultado da ordenação realizado
    // Se o número de argumentos for igual a 5 ele verifica se o quinto argumento é igual a "-P", se for verdadeiro a função strcmp retorna 1
    if (argc == 5 && !strcmp(argv[4], "-P")) imprimirDados = 1;
    else imprimirDados = 0;
    // Arquivo contendo todos os dados dos alunos, Arquivo temporário para conter apenas os N primeiros alunos
    FILE *arqProvao, *arqTemporario;
    // Verifica se respeita todas as condições e ordena o arquivo temporário de acordo com a situação
    if (quantidade > 0 && (situacao >= 1 && situacao <= 3) && (metodo >= 1 && metodo <= 3)){
        // Abre o arquivo PROVAO.txt no modo de leitura após passar todos os testes
        if ((arqProvao = fopen("PROVAO.txt", "r")) == NULL){
            puts("> Nao foi possivel abrir o arquivo!\n");
            return 1;
        }
        // Abre o arquivo temporário que irá ser utilizado para a ordenação
        if ((arqTemporario = fopen("arqTemporario.bin", "w+b")) == NULL){
            puts("> Nao foi possivel abrir o arquivo!\n");
            return 1;
        }
        int leiturasTemp = 0, escritasTemp = 0, comparacoesTemp = 0;
        // Método responsável por criar o arquivo temporário com a quantidade de itens informada através do arquivo PROVAO.txt
        criarArquivoTemporario(arqProvao, arqTemporario, quantidade, &escritasTemp);
        fclose(arqProvao);
        // Ordenar o arquivo temporario de forma crescente
        if (situacao == 1) intercalacao(1, quantidade, arqTemporario, &leiturasTemp, &escritasTemp, &comparacoesTemp);
        else if (situacao == 2){// Ordenar o arquivo temporario de forma descrescente
            intercalacao(1, quantidade, arqTemporario, &leiturasTemp, &escritasTemp, &comparacoesTemp);
            inverterSaida(arqTemporario, quantidade);
        }
    } else if (metodo < 1 || metodo > 4){
        printf("Informe um método válido!\n");
        return 0;
    } else if (quantidade <= 0){
        printf("Informe uma quantide de registros valida!\n");
        return 0;
    } else if (situacao < 1 || situacao > 3){
        printf("Informe uma situacao valida!\n");
        return 0;
    }
    rewind(arqTemporario);
    // Caso a variável 'imprimirDados' seja igual a 1 é impresso no console os dados antes de serem ordenados
    if (imprimirDados){
        printf("\n> Arquivo temporario ANTES dos dados serem ordenados:\n\n");
        for (int i = 0; i < quantidade; i++){
            Registro registro;
            fread(&registro, sizeof(Registro), 1, arqTemporario);
            printf("\t%d - %ld\t%.2lf\t%s\t%s\t%s\n", i + 1, registro.numeroInscricao, registro.nota, registro.estado, registro.cidade, registro.curso);
        }
        rewind(arqTemporario);
    }
    // Variáveis responsáveis para analisar complexidade de cada método
    int numeroDeLeituras = 0, numeroDeEscritas = 0, numeroDeComparacoesEntreValores = 0;
    clock_t tempoInicialDeExecucao = clock(), tempoTotalDeExecucao;
    // Através do primeiro paramento da linha comando é selecionado qual metodo executar
    if (metodo == 1){
        printf("\n> Intercalacao Balanceada de varios caminhos - (Metodo de ordenacao)\n");
        intercalacao(1, quantidade, arqTemporario, &numeroDeLeituras, &numeroDeEscritas, &numeroDeComparacoesEntreValores);
    } else if (metodo == 2){
        printf("\n> Intercalacao Balanceada de varios caminhos - Selecao por substituicao\n");
        intercalacao(2, quantidade, arqTemporario, &numeroDeLeituras, &numeroDeEscritas, &numeroDeComparacoesEntreValores);
    } else if (metodo == 3){
        printf("\n> Quicksort externo\n");
        FILE* ArqLEs = fopen("arqTemporario.bin", "r+b");
        FILE* ArqEi = fopen("arqTemporario.bin", "r+b");
        QuickSortExterno(&arqTemporario, &ArqEi, &ArqLEs, 1, quantidade, &numeroDeLeituras, &numeroDeEscritas, &numeroDeComparacoesEntreValores);
        fflush(arqTemporario);
        fclose(ArqEi);
        fclose(ArqLEs);
    }
    tempoTotalDeExecucao = clock() - tempoInicialDeExecucao;
    rewind(arqTemporario);
    // Caso a variável 'imprimirDados' seja igual a 1 é impresso no console os dados apos serem ordenados
    if (imprimirDados){
        printf("\n\t> Arquivo temporario DEPOIS dos dados serem ordenados\n\n");
        for (int i = 0; i < quantidade; i++){
            Registro registro;
            fread(&registro, sizeof(Registro), 1, arqTemporario);
            printf("\t\t%d - %ld\t%.2lf\t%s\t%s\t%s\n", i + 1, registro.numeroInscricao, registro.nota, registro.estado, registro.cidade, registro.curso);
        }
    }
    printf("\n\t> Numero total de leituras da memoria externa para a interna: %d vezes!\n", numeroDeLeituras);
    printf("\n\t> Numero total de escritas da memoria interna para a externa: %d vezes!\n", numeroDeEscritas);
    printf("\n\t> Numero total de comparacoes entre os valores: %d vezes!\n", numeroDeComparacoesEntreValores);
    printf("\n\t> Tempo de execucao: %.4lf segundos!\n\n", tempoTotalDeExecucao / 1000.0);
    //todo queryPerformanceCounter???
    fclose(arqTemporario);
    remove("arqTemporario.bin");
    return 0;
}
