#ifndef LEARQUIVO_H
#define LEARQUIVO_H

#define TAMPAGINA 100
#define MAXTABELA 12000

typedef struct Registro{
	int chave; // Chave de pesquisa
    long int dado1;
	char dado2[1000]; 
    char dado3[5000];
}Registro;

void preencherDadosAleatorios(Registro* dados, int tamanhoDados2, int tamanhoDados3, char cadeias_permitidas[]);

int criaArquivo(int operacao, int tamanho); // Funções para inicializar meu arquivo binário

#endif