#ifndef ACESSOSEQUENCIAL_H
#define ACESSOSEQUENCIAL_H

#define ITENSPAGINA 100

#include <stdbool.h>

typedef struct{
	int chave;
	int posicao;
}TIndice;

bool pesquisaSequencial (TIndice *, int, Registro *, FILE *, bool, int *, int *);

#endif