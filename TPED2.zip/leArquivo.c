#include "leArquivo.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void preencherDadosAleatorios(Registro* dados, int tamanhoDados2, int tamanhoDados3, char cadeias_permitidas[]){
    dados->dado1 = rand();
    for(int j = 0; j < tamanhoDados2; j++)
        dados->dado2[j] = cadeias_permitidas[rand() % strlen(cadeias_permitidas)];
    dados->dado2[tamanhoDados2] = '\0';
    for (int j = 0; j < tamanhoDados3; j++)
        dados->dado3[j] = cadeias_permitidas[rand() % strlen(cadeias_permitidas)];
    dados->dado3[tamanhoDados3] = '\0';
}

int criaArquivo(int operacao, int tamanho){
    FILE *arq;
    Registro dados;
    int tamanhoDados2 = 999;
    int tamanhoDados3 = 4999;
    int vetorAux[tamanho];
    int troca, aux1, aux2;
    char cadeias_permitidas[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    fflush(stdout);

    if((arq = fopen("dados.bin", "wb")) == NULL){
        printf("Erro ao abrir o arquivo dados.bin.\n");
        return 0;
    }

    srand(time(NULL));

    switch (operacao)
    {
    case 1: // Arquivo ordenado ascendentemente
        for(int i = 0; i < tamanho; i++){
            dados.chave = i;
            preencherDadosAleatorios(&dados, tamanhoDados2, tamanhoDados3, cadeias_permitidas);
            fwrite(&dados, sizeof(dados), 1, arq);
        }
    break;
    case 2: // Arquivo ordenado descendentemente
        for(int i = tamanho - 1; i >= 0; i--){
            dados.chave = i;
            preencherDadosAleatorios(&dados, tamanhoDados2, tamanhoDados3, cadeias_permitidas);
            fwrite(&dados, sizeof(dados), 1, arq);
        }
    break;
    case 3: // Arquivo ordenado aleatóriamente
        for(int i = 0; i < tamanho; i++)
            vetorAux[i] = i;
        
        // Agora para deixar o arquivo aleatorio eu irei "brincar" com os índices
        for(int i = 0; i < tamanho * 5; i++){
            aux1 = rand() % tamanho;
            aux2 = rand() % tamanho;

            troca = vetorAux[aux1];
            vetorAux[aux1] = vetorAux[aux2];
            vetorAux[aux2] = troca;
        }
        // Coloco meu vetorAux na minha chave
        for(int i=0; i<tamanho; i++){
            dados.chave = vetorAux[i];
            preencherDadosAleatorios(&dados, tamanhoDados2, tamanhoDados3, cadeias_permitidas);
            fwrite(&dados, sizeof(dados), 1, arq);
        }
    break;
    default:
        printf("Nao existe situacao associada ao inteiro %d.\nPrograma finalizado.\n", operacao);
        exit(1);
    break;
    }

    return 1;
}