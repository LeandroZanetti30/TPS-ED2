#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "leArquivo.h"
#include "arvoreB.h"
#include "acessoSequencial.h"
#include "arvoreBinaria.h"
#include "bEstrela.h"

clock_t t1, t2; //Cronometro para medir tempo de execucao do codigo

void resultadoPesquisa(bool resultado, Registro saida, int leiturasCriacaoIndice, int leituras, int contadorComparaCriacaoIndice, int contadorCompara){
	t2 = clock();
    if (resultado){
        printf("\nChave %d foi encontrada! Transferencias(CriacaoIndice): %d, Transferencias(Pesquisa): %d, Comparacoes(CriacaoIndice): %d, Comparacoes(Pesquisa): %d\n", 
                saida.chave, leiturasCriacaoIndice, leituras, contadorComparaCriacaoIndice, contadorCompara);
        printf("Dado1: %ld, Dado2: %s\nDado3: %s\n", saida.dado1, saida.dado2, saida.dado3); // dados da chave encontrada
    } else
        printf("\nChave %d nao foi encontrada! Transferencias(CriacaoIndice): %d, Transferencias(Pesquisa): %d, Comparacoes(CriacaoIndice): %d, Comparacoes(Pesquisa): %d\n", 
                saida.chave, leiturasCriacaoIndice, leituras, contadorComparaCriacaoIndice, contadorCompara);
}

int main(int argc, char **argv){
    FILE *arq;
    Registro dados;
    Registro x;
    TIndice tabela[MAXTABELA];
    TipoApontador arvoreB = NULL;
    TApEstrela arvoreBEstrela = NULL;
    int pos = 0, leituras = 0, contadorCompara = 0, leiturasCriacaoIndice = 0, contadorComparaCriacaoIndice = 0;
    int metodo, quantidade, situacao, chave;
    bool argumentoOpcional = false, achou = false;

    //Conversão da entrada.
    if (argc > 4){
        metodo = atoi(argv[1]);
	    quantidade = atoi(argv[2]);
	    situacao = atoi(argv[3]);
	    chave = atoi(argv[4]);
    } else {
        printf("Formato invalido. Formato esperado: .exe <método> <quantidade> <situação> <chave> [-P]\n");
        abort();
    }
    if (argc == 6)
        argumentoOpcional = true;
    t1 = clock();
    Registro saida;
    saida.chave = chave;
    criaArquivo(situacao, quantidade);
    if ((arq = fopen("dados.bin", "rb")) == NULL){
        printf("Erro na leitura do arquivo.");
        exit(1);
    }
	t2 = clock();
	printf("\nTempo de criacao: %.3lf", (t2 - t1) / 1000.0);
    t1 = clock();
    switch(metodo){ 
        case 1: // Acesso sequencial indexado (Precisa de um arquivo ordenado crescente).
            if (situacao != 1){
                printf("Erro: Acesso sequencial indexado precisa de um arquivo ordenado ascendentemente\n");
                exit(1);
            }

            // gera a tabela de indices;
            while ((fread(&x, sizeof(x), 1, arq)) == 1){
                leiturasCriacaoIndice++; // Nao há um ++ fora do while pois são apenas transferencias e não checagens;
				
                fseek(arq, (ITENSPAGINA - 1) * sizeof(Registro), SEEK_CUR);

				tabela[pos].chave = x.chave;
				tabela[pos].posicao = pos+1;
				pos++;
            }
            if (argumentoOpcional)
				printf("\nChaves verificadas durante a pesquisa de acesso sequencial indexado:");
            achou = pesquisaSequencial(tabela, pos, &saida, arq, argumentoOpcional, &contadorCompara, &leituras);
            resultadoPesquisa(achou, saida, leiturasCriacaoIndice, leituras, contadorComparaCriacaoIndice, contadorCompara);
        break;
        case 2: // Arvore binaria de pesquisa externa
            if (criaArvoreBinaria(&contadorComparaCriacaoIndice, &leiturasCriacaoIndice, situacao)){
                if (argumentoOpcional)
					printf("\nChaves verificadas durante a pesquisa da arvore binaria externa:");
                achou = pesquisaArvoreBinaria(&saida, argumentoOpcional, &contadorCompara, &leituras);
                resultadoPesquisa(achou, saida, leiturasCriacaoIndice, leituras, contadorComparaCriacaoIndice, contadorCompara);
            }
        break;
        case 3: // Arvore B
            InicializaArvoreB(arvoreB);
            while ((fread(&dados, sizeof(dados), 1, arq)) == 1){
                leiturasCriacaoIndice++;
                InsereArvoreB(dados, &arvoreB, &contadorComparaCriacaoIndice);
            }
            if (argumentoOpcional)
				printf("\nChaves verificadas durante a pesquisa da arvore B:");
            achou = PesquisaArvoreB(&saida, arvoreB, &contadorCompara, argumentoOpcional);
            resultadoPesquisa(achou, saida, leiturasCriacaoIndice, leituras, contadorComparaCriacaoIndice, contadorCompara);
        break; 
        case 4: // Arvore B*
            inicializaBEstrela(arvoreBEstrela);
            while ((fread(&dados, sizeof(dados), 1, arq)) == 1){
                leiturasCriacaoIndice++;
                insereBEstrela(dados, &arvoreBEstrela, &contadorComparaCriacaoIndice);
            }
            if (argumentoOpcional)
				printf("\nChaves verificadas durante a pesquisa da arvore B estrela:");
            pesquisaBEstrela(&saida, &arvoreBEstrela, &achou, &contadorCompara, argumentoOpcional);
            resultadoPesquisa(achou, saida, leiturasCriacaoIndice, leituras, contadorComparaCriacaoIndice, contadorCompara);
        break;
        default:
            printf("Nao existe um metodo associado ao inteiro %d.\nPrograma finalizado.\n", metodo);
            exit(1);
    }
	
    printf("\nTempo de pesquisa: %.3lf", (t2 - t1) / 1000.0);
    return 0;
}