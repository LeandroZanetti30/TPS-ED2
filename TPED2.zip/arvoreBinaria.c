#include <stdio.h>
#include <stdbool.h>
#include "arvoreBinaria.h"

bool criaArvoreBinaria(int *indiceContComp, int *indiceContMem, int sit){
	FILE *arvore, *arq;
	Registro dado;
	TBinaria nodo;
	int index = 1;
	if ((arvore = fopen("arvore.bin", "w+b")) == NULL){
		printf("Falha na criacao do arquivo!");
		return false;
	}
	if ((arq = fopen("dados.bin", "rb")) == NULL){
		printf("Falha na abertura do arquivo!");
		return false;
	}
	(*indiceContMem)++;
	fread(&dado, sizeof(dado), 1, arq);
	nodo.registro = dado;
	nodo.pEsq = -1;	//Preenche o apontador do lado esquerdo com o valor -1
	nodo.pDir = -1;	//Preenche o apontador do lado direito com o valor -1
	fwrite(&nodo, sizeof(nodo), 1, arvore);  //Insere o primeiro registro na árvore
	//? (*indiceContMem)++;
	while(fread(&dado, sizeof(dado), 1, arq)==1){	
		(*indiceContMem)++;
		nodo.registro = dado;
		nodo.pEsq = -1;
		nodo.pDir = -1;
		fseek(arvore, 0, SEEK_END);
		fwrite(&nodo, sizeof(nodo), 1, arvore);
		if (sit == 1 || sit == 2){
			fseek(arvore,  -2 * ((long long int)sizeof(nodo)), SEEK_CUR);  //Volta dois registros na árvore
			fread(&nodo, sizeof(nodo), 1, arvore);
			(*indiceContMem)++;
			fseek(arvore, -1 * ((long long int)sizeof(nodo)), SEEK_CUR);  //Volta ao registro que acabou de ler
		}else{
			rewind(arvore);	// Retorna ao inicio do arquivo
			if (fread(&nodo, sizeof(nodo), 1, arvore) == 1)	//Faz a leitura do primeiro registro da árvore
				(*indiceContMem)++;
			rewind(arvore);	// Retorna ao inicio do arquivo	
		}
		while(true){	//Entra no laço até que o registro a ser inserido seja devidamente apontado pelos demais registros
			(*indiceContComp)++;
			if (dado.chave < nodo.registro.chave){	//Compara se a chave a ser inserida na árvore é menor que a chave atual da árvore
				if(nodo.pEsq == -1){	//Verifica se o apontador do lado esquerdo do registro não aponta para outro registro
					nodo.pEsq = index;	//Faz com que o apontador da esquerda aponte para o novo registro
					fwrite(&nodo, sizeof(nodo), 1, arvore);	//Reescreve o registro com o novo apontador
					break;	//Sai do laço
				}else{
					fseek(arvore, nodo.pEsq * sizeof(nodo), SEEK_SET);	//Salta para o registro apontado a esquerda
					if (fread(&nodo, sizeof(nodo), 1, arvore) == 1)	//Lê o registro da esquerda
						(*indiceContMem)++;			
					fseek(arvore, -1 * ((long long int)sizeof(nodo)), SEEK_CUR);	//Volta ao registro que acabou de ler
				}
			}else{	//Neste ponto a chave a ser inserida na árvore é maior que a chave atual da árvore
				if(nodo.pDir == -1){	//Verifica se o apontador do lado direito do registro não aponta para outro registro
					nodo.pDir = index;	//Faz com que o apontador da direita aponte para o novo registro
					fwrite(&nodo, sizeof(nodo), 1, arvore);	//Reescreve o registro com o novo apontador
					break;	//Sai do laço
				}else{
					fseek(arvore, nodo.pDir * sizeof(nodo), SEEK_SET);	//Salta para o registro apontado a direita
					if (fread(&nodo, sizeof(nodo), 1, arvore) == 1)	//Lê o registro da direita
						(*indiceContMem)++;				
					fseek(arvore, -1 * ((long long int)sizeof(nodo)), SEEK_CUR);	//Volta ao registro que acabou de ler
				}
			}
		}	
		index++;	//Incrementa a posição do último registro
	}
	fclose(arvore);
	fclose(arq);
	return true;
}

bool pesquisaArvoreBinaria(Registro *sample, bool argumentoOpcional, int *pesqContComp, int *pesqContMem){
	FILE *arvore;
	TBinaria nodo;
	if ((arvore = fopen("arvore.bin", "rb")) == NULL){
		printf("Falha na abertura do arquivo!");
		return false;
	}
	while (fread(&nodo, sizeof(nodo), 1, arvore) == 1){
		(*pesqContMem)++;
		(*pesqContComp)++;
		if (sample->chave == nodo.registro.chave){
			if (argumentoOpcional){
				printf("%d, ", nodo.registro.chave);
				fflush(stdout);
			}
			*sample = nodo.registro;
			fclose(arvore);
			return true;
		}else{
			(*pesqContComp)++;
			if (sample->chave < nodo.registro.chave){
				if (argumentoOpcional){
					printf("%d, ", nodo.registro.chave);
					fflush(stdout);
				}
				if (nodo.pEsq != -1) 
					fseek(arvore, nodo.pEsq * sizeof(nodo), SEEK_SET); // Movimentação do apontador até a chave ser encontrada;
				else{ // Se o apontador chegar em -1 não foi possível encontrar a chave no arquivo;
					fclose(arvore);
					return false;
				}
			}else{
				if (argumentoOpcional)
					printf("%d, ", nodo.registro.chave);
				if (nodo.pDir != -1)
					fseek(arvore, nodo.pDir * sizeof(nodo), SEEK_SET); // Movimentação do apontador até a chave ser encontrada;
				else{ // Se o apontador chegar em -1 não foi possível encontrar a chave no arquivo;
					fclose(arvore);
					return false;
				}
			}
		}
	}
	fclose(arvore);
	return true;
}