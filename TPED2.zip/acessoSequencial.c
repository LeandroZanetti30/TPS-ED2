#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "leArquivo.h"
#include "acessoSequencial.h"

bool pesquisaSequencial(TIndice tab[], int tam, Registro *item, FILE *arq, bool aux, int *contadorCompara, int *contadorMem){

    Registro pagina[ITENSPAGINA];
	int i = 0, quantItens;
	long desloc;

	//Busca a página onde o item pode ser localizado.
	while (i < tam && tab[i].chave <= item->chave){
		(*contadorCompara)++; // comparação entre chaves durante a pesquisa;
		if (aux)
			printf("%d, ", pagina[i].chave);
		i++;
	}
	(*contadorCompara)++;
	if (i == 0) 
		return false;
	else{
		if (i < tam){ // a ultima página pode não estar completa
			quantItens = ITENSPAGINA;
		}
		else{
			fseek(arq, 0, SEEK_END);
			quantItens = (ftell(arq)/sizeof(Registro))%ITENSPAGINA;
			if (quantItens == 0)
				quantItens = ITENSPAGINA;
		}
		
		// lê a página desejada do arquivo		
		desloc = (tab[i-1].posicao-1)*ITENSPAGINA*sizeof(Registro);
		fseek (arq, desloc, SEEK_SET);
		fread (&pagina, sizeof(Registro), quantItens, arq);
		(*contadorMem)++;
		
		// pesquisa sequencial na página lida
		for (i=0; i < quantItens; i++){
			if (aux)
				printf("%d, ", pagina[i].chave);
			(*contadorCompara)++;
			if (pagina[i].chave == item->chave){
				*item = pagina[i];
				return true;
			}
		}
		return false;
	}
}