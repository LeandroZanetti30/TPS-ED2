#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "arvoreB.h"

void InicializaArvoreB(TipoApontador Arvore){ // O apontador que indica a raiz da árvore recebe valor nulo;
	Arvore = NULL;
}

void InsereNaPagina(TipoApontador Ap, Registro Reg, TipoApontador ApDir, int *contadorCompara){
	bool NaoAchouPosicao;
	int index;
	index = Ap->n;
	NaoAchouPosicao = (index > 0);
	while (NaoAchouPosicao){
		(*contadorCompara)++;
		if (Reg.chave >= Ap->r[index-1].chave){	// Compara se a chave do registro a ser inserido na página é maior ou igual a última chave presente na página 
			NaoAchouPosicao = false;
			break;
		}
		Ap->r[index] = Ap->r[index-1];	// Transfere o registro da posição (index - 1) para uma posição a frente,
		Ap->p[index+1] = Ap->p[index];	// consequentemente o apontador também é transferido
		index--;
		if (index < 1)
			NaoAchouPosicao = false;
	}
	Ap->r[index] = Reg;	// Copia o novo registro para a posição liberada acima
	Ap->p[index+1] = ApDir;	// Atualiza o apontador direito desse novo registro
	Ap->n++;	// Incrementa a quantidade de registros na página
}

void Ins(Registro Reg, TipoApontador Ap, bool *Cresceu, Registro *RegRetorno, TipoApontador *ApRetorno, int *contadorCompara){
	int i = 1, j;
	TipoApontador TmpPont;
	if (Ap == NULL){	// Verifica se Ap é NULL, caso seja, uma página folha foi atingida
		*Cresceu = true;
		(*RegRetorno) = Reg;
		(*ApRetorno) = NULL;
		return;
	}
	while (i < Ap->n && Reg.chave > Ap->r[i-1].chave){	// Varre a página enquanto o registrador i for menor que a quantidade de registros dessa página e enquanto a chave a ser inserida for maior do que uma das chaves presentes na página 
		i++;
		(*contadorCompara)++;
	}
	(*contadorCompara) += 2; //Incrementa a ultima comparacao feita no while juntamente com o if da proxima linha
	if (Reg.chave == Ap->r[i-1].chave){	// Verifica se o registro a ser inserido já se encontra na árvore
		*Cresceu = false; // Erro: Registro já está presente
		return;
	}
	(*contadorCompara)++;
	if (Reg.chave < Ap->r[i-1].chave) i--;	// Verifica se o registro a ser inserido possui chave menor que a do último registro verificado na página
	
	Ins(Reg, Ap->p[i], Cresceu, RegRetorno, ApRetorno, contadorCompara);	// Faz a chamada recursiva até que uma página folha seja atingida
	if (!*Cresceu)	// Se a página folha não foi atingida retorna
		return;
	if (Ap->n < MM){	// Verifica se a página tem espaço para inserção de um novo registro
		InsereNaPagina(Ap, *RegRetorno, *ApRetorno, contadorCompara);
		*Cresceu = false;
		return;
	}
	// A partir desse ponto, a página folha é dividida, uma vez que seu tamanho máximo de registros foi excedido
	TmpPont = (TipoApontador)malloc(sizeof(TipoPagina));	
	TmpPont->n = 0;
	TmpPont->p[0] = NULL;
	if (i < (MM/2 + 1)){	// Insere metade dos registros da página cheia para a nova página criada
		InsereNaPagina(TmpPont, Ap->r[MM -1], Ap->p[MM], contadorCompara);
		Ap->n--;
		InsereNaPagina(Ap, *RegRetorno, *ApRetorno, contadorCompara);
	}else
		InsereNaPagina(TmpPont, *RegRetorno, *ApRetorno, contadorCompara);
	for(j = MM/2+2; j <= MM; j++)
		InsereNaPagina(TmpPont, Ap->r[j-1], Ap->p[j], contadorCompara);
	Ap->n = MM/2;	// Atualiza a quantidade de dados na página
	TmpPont->p[0] = Ap->p[MM/2+1];
	*RegRetorno = Ap->r[MM/2];	// Retorna o registro do meio para a página pai
	*ApRetorno = TmpPont;
}

void InsereArvoreB(Registro Reg, TipoApontador *Ap, int *contadorCompara){
	bool Cresceu;
	Registro RegRetorno;
	TipoPagina *ApRetorno, *ApTemp;
	Ins(Reg, *Ap, &Cresceu, &RegRetorno, &ApRetorno, contadorCompara);
	if (Cresceu){	// Neste ponto a raiz é dividida, e é gerada uma nova raiz. A altura da árvore aumenta.
		ApTemp = (TipoPagina*) malloc (sizeof(TipoPagina));
		ApTemp->n = 1;
		ApTemp->r[0] = RegRetorno;
		ApTemp->p[1] = ApRetorno;
		ApTemp->p[0] = *Ap;
		*Ap = ApTemp;
	}
}

bool PesquisaArvoreB(Registro* x, TipoApontador Ap, int *contadorCompara, bool argumentoOpcional){
    int i = 1;
    if(Ap == NULL)
        return false; //Registro nao esta presente na arvore
    while(i < Ap->n && x->chave > Ap->r[i-1].chave){
		if (argumentoOpcional)
			printf("%d, ", Ap->r[i-1].chave);
		(*contadorCompara)++;
        i++;
	} //Pesquisa sequencial para se encontrar o intervalo desejado
	(*contadorCompara) += 2;
    if(x->chave == Ap->r[i-1].chave){ 
		if (argumentoOpcional)
			printf("%d, ", Ap->r[i-1].chave);
        *x = Ap->r[i-1]; //Achou a chave desejada
        return true;
    }
	(*contadorCompara)++;
    if(x->chave < Ap->r[i-1].chave){//Ativacao recursiva da Pesquisa em uma das subárvores (esquerda ou direita)
		if (argumentoOpcional)
			printf("%d, ", Ap->r[i-1].chave);
        return PesquisaArvoreB(x, Ap->p[i-1], contadorCompara, argumentoOpcional);
	}
    else{
		if (argumentoOpcional)
			printf("%d, ", Ap->r[i-1].chave);
        return PesquisaArvoreB(x, Ap->p[i], contadorCompara, argumentoOpcional);
	}
}

void Imprime(TipoApontador arvore){ //Imprime em ordem os valores da árvore B
    if (arvore == NULL){
        return;
	} 
	for (int i = 0; i <= arvore->n; i++){
		Imprime(arvore->p[i]);
		if (i != arvore->n)
			printf(" %d ", arvore->r[i].chave);
	}
}

void Imprime3(TipoApontador arvore, int nivelDoNo){ //Imprime em pos-ordem os valores da árvore B, para visualizar melhor os nós e seus níveis
	if (arvore == NULL)
		return;
	for(int i = 0; i <= arvore->n; i++)
		Imprime3(arvore->p[i], nivelDoNo + 1);
	printf("no(%d):", nivelDoNo);
	for(int i = 0; i < arvore->n; i++)
		printf(" %d ", arvore->r[i].chave);
	printf("\n");
}

//--------------------------------------------- METODOS PARA REMOCAO NA ÁRVORE B

void Reconstitui(TipoApontador ApPag, TipoApontador ApPai, int PosPai, bool *Diminuiu){
	TipoPagina *Aux;
	int lixo; //isso aki n serve pra nd
	int DispAux, j;
	if (PosPai < ApPai->n){ //TipoPagina a direita de ApPag
		Aux = ApPai->p[PosPai + 1];
		DispAux = (Aux->n - MM/2 + 1) / 2;
		ApPag->r[ApPag->n] = ApPai->r[PosPai];
		ApPag->p[ApPag->n + 1] = Aux->p[0];
		ApPag->n++;
		if (DispAux > 0){ //Existe espaço: transfere de Aux para ApPag
			for (j = 1; j < DispAux; j++) InsereNaPagina(ApPag, Aux->r[j - 1], Aux->p[j], &lixo);
			ApPai->r[PosPai] = Aux->r[DispAux - 1];
			Aux->n -= DispAux;
			for (j = 0; j < Aux->n; j++) Aux->r[j] = Aux->r[j + DispAux];
			for (j = 0; j <= Aux->n; j++) Aux->p[j] = Aux->p[j + DispAux];
			*Diminuiu = false;
		} else { //Fusão: intercala Aux em ApPag e libera Aux
			for (j = 1; j <= MM/2; j++) InsereNaPagina(ApPag, Aux->r[j - 1], Aux->p[j], &lixo);
			free(Aux);
			for (j = PosPai + 1; j < ApPai->n; j++){
				ApPai->r[j - 1] = ApPai->r[j];
				ApPai->p[j] = ApPai->p[j + 1];
			}
			ApPai->n--;
			if (ApPai->n >= MM/2) *Diminuiu = false;
		}
	} else { //TipoPagina a esquerda de ApPag
		Aux = ApPai->p[PosPai - 1];
		DispAux = (Aux->n - MM/2 + 1) / 2;
		for (j = ApPag->n; j >= 1; j--) ApPag->r[j] = ApPag->r[j - 1];
		ApPag->r[0] = ApPai->r[PosPai - 1];
		for (j = ApPag->n; j >= 0; j--) ApPag->p[j + 1] = ApPag->p[j];
		ApPag->n++;
		if (DispAux > 0){ //Existe espaço: transfere de Aux para ApPag
			for (j = 1; j < DispAux; j++) InsereNaPagina(ApPag, Aux->r[Aux->n - j], Aux->p[Aux->n - j + 1], &lixo);
			ApPag->p[0] = Aux->p[Aux->n - DispAux + 1];
			ApPai->r[PosPai - 1] = Aux->r[Aux->n - DispAux];
			Aux->n -= DispAux;
			*Diminuiu = false;
		} else { //Fusão: intercala ApPag em Aux e libera ApPag
			for (j = 1; j <= MM/2; j++) InsereNaPagina(Aux, ApPag->r[j - 1], ApPag->p[j], &lixo);
			free(ApPag);
			ApPai->n--;
			if (ApPai->n >= MM/2) *Diminuiu = false;
		}
	}
}

void Antecessor(TipoApontador Ap, int Ind, TipoApontador ApPai, bool *Diminuiu){
	if (ApPai->p[ApPai->n] != NULL){
		Antecessor(Ap, Ind, ApPai->p[ApPai->n], Diminuiu);
		if (*Diminuiu) Reconstitui(ApPai->p[ApPai->n], ApPai, ApPai->n, Diminuiu);
		return;
	}
	Ap->r[Ind - 1] = ApPai->r[ApPai->n - 1];
	ApPai->n--;
	*Diminuiu = (ApPai->n < MM/2);
}

void Ret(int ch, TipoApontador *Ap, bool *Diminuiu){
	int j, Ind = 1;
	TipoApontador Pag;
	if (*Ap == NULL){
		*Diminuiu = false;
		return; //Erro: registro nao esta na arvore
	}
	Pag = *Ap;
	while(Ind < Pag->n && ch > Pag->r[Ind - 1].chave) Ind++;
	if (ch == Pag->r[Ind - 1].chave){
		if (Pag->p[Ind - 1] == NULL){ //TipoPagina folha
			Pag->n--;
			*Diminuiu = (Pag->n < MM/2);
			for (j = Ind; j <= Pag->n; j++){
				Pag->r[j - 1] = Pag->r[j];
				Pag->p[j] = Pag->p[j + 1];
			}
			return;
		}
		//TipoPagina nao eh folha: trocar com antecessor
		Antecessor(*Ap, Ind, Pag->p[Ind - 1], Diminuiu);
		if (*Diminuiu) Reconstitui(Pag->p[Ind - 1], *Ap, Ind - 1, Diminuiu);
		return;
	}
	if (ch > Pag->r[Ind - 1].chave) Ind++;
	Ret(ch, &Pag->p[Ind - 1], Diminuiu);
	if (*Diminuiu) Reconstitui(Pag->p[Ind - 1], *Ap, Ind - 1, Diminuiu);
}

void Retira(int ch, TipoApontador *Ap){
	bool Diminuiu; // Indica se uma quantidade menor do que M itens passa a ocupar a página
	TipoApontador Aux;
	Ret(ch, Ap, &Diminuiu);
	if (Diminuiu && (*Ap)->n == 0){ //Arvore diminuiu na altura
		Aux = *Ap;
		*Ap = Aux->p[0];
		free(Aux);
	}
}