#ifndef ARVOREBINARIA_H
#define ARVOREBINARIA_H

#include <stdbool.h>
#include "leArquivo.h"

typedef struct{
	int pEsq, pDir;
	Registro registro;
}TBinaria;

bool criaArvoreBinaria(int *, int *, int);
bool pesquisaArvoreBinaria(Registro *, bool, int *, int *);

#endif